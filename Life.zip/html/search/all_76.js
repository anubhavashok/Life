var searchData=
[
  ['value_5ftype',['value_type',['../classHandle.html#aee908bcd2d431c03a14290e1757adb41',1,'Handle']]]
];
