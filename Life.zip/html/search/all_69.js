var searchData=
[
  ['is_5falive',['is_alive',['../classAbstractCell.html#a0d59b629d2efebdce1ace4917de76dee',1,'AbstractCell::is_alive()'],['../classCell.html#a6fab71e45c9a5ce38bbc6610c5c6a4e8',1,'Cell::is_alive()'],['../classConwayCell.html#a595428d5ac3cdc6acb682402a5ab0737',1,'ConwayCell::is_alive()'],['../classFredkinCell.html#abe9f18ada31ae38dffa35bc8b52f6987',1,'FredkinCell::is_alive()']]]
];
