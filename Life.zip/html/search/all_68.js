var searchData=
[
  ['handle',['Handle',['../classHandle.html',1,'Handle&lt; T &gt;'],['../classHandle.html#acae37b04162b307d903b008a52b6bf95',1,'Handle::Handle(pointer p)'],['../classHandle.html#ad4a4e85ee6c84a4acb84f546d475b09c',1,'Handle::Handle(const Handle &amp;that)']]],
  ['handle_2eh',['Handle.h',['../Handle_8h.html',1,'']]],
  ['handle_3c_20abstractcell_20_3e',['Handle< AbstractCell >',['../classHandle.html',1,'']]]
];
