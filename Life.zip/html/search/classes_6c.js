var searchData=
[
  ['life',['Life',['../classLife.html',1,'']]]
];
