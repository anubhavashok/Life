var searchData=
[
  ['abstractcell',['AbstractCell',['../classAbstractCell.html#a6e09d3dc50ef188d85533d8f68fbc2a5',1,'AbstractCell::AbstractCell(bool)'],['../classAbstractCell.html#a1a32801663a2fc4f8dbc05cc5f272547',1,'AbstractCell::AbstractCell(AbstractCell &amp;)']]],
  ['alive_5fneighbors_5fconway',['alive_neighbors_conway',['../classLife.html#a024af157d0acd46b8056ebdae2d1fde2',1,'Life']]],
  ['alive_5fneighbors_5ffredkin',['alive_neighbors_fredkin',['../classLife.html#afe42fb2f092ed4c1d3803805042ec9d3',1,'Life']]]
];
