var searchData=
[
  ['_7eabstractcell',['~AbstractCell',['../classAbstractCell.html#ab992d1a62eb7835ac0e07b645479fcd7',1,'AbstractCell']]],
  ['_7ehandle',['~Handle',['../classHandle.html#af44781eaf3bf4a8dc43c03bbffb6a99b',1,'Handle']]]
];
