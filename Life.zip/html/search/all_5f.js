var searchData=
[
  ['_5fgrid',['_grid',['../classLife.html#acbc47367a25db738417ea6ea927e954d',1,'Life']]],
  ['_5fp',['_p',['../classHandle.html#ad74f33e968f57f03dd7e6a2be10b8cd2',1,'Handle']]]
];
