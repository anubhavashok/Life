var searchData=
[
  ['operator_21_3d',['operator!=',['../classHandle.html#acd893d8ba3565c973c9f6ec1d8c9b512',1,'Handle']]],
  ['operator_3d_3d',['operator==',['../classHandle.html#a8a1b1362bff49cc0f4a7a0792cf5f2bd',1,'Handle']]]
];
