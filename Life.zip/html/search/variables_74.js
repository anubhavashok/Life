var searchData=
[
  ['type',['type',['../classConwayCell.html#a44eb4ed23e9802a630a6f8f91fbd034f',1,'ConwayCell::type()'],['../classFredkinCell.html#ad9dbb6ecc66478e2b37c1f19c493e601',1,'FredkinCell::type()']]]
];
