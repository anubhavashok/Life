var searchData=
[
  ['y',['y',['../classLife.html#aa0398b6419b9bdd38429067c91aeaff4',1,'Life']]]
];
