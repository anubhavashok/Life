var searchData=
[
  ['get',['get',['../classHandle.html#ac8d3293e5dd407a126726e6f9f6dcc5e',1,'Handle::get()'],['../classHandle.html#a43f144b815aa32fe2f2bf28627ed341b',1,'Handle::get() const ']]],
  ['get_5fage',['get_age',['../classAbstractCell.html#ad126d695375e79691038e4c152515c10',1,'AbstractCell::get_age()'],['../classCell.html#a3fa8cb43100104a8b2f459c63821fd19',1,'Cell::get_age()'],['../classFredkinCell.html#a0a4d5eb7f4df26732d5a810317f62e79',1,'FredkinCell::get_age()']]],
  ['get_5ftype',['get_type',['../classAbstractCell.html#ad36d98e5cbce523d04f38d1fdd868740',1,'AbstractCell::get_type()'],['../classCell.html#a5ee9918c90f5e1602109c99f3da57839',1,'Cell::get_type()'],['../classConwayCell.html#ad52b75602abccff927ee1ae4848ff9c9',1,'ConwayCell::get_type()'],['../classFredkinCell.html#a3bde1fa92985ef70f60c9c940aa02909',1,'FredkinCell::get_type()']]]
];
