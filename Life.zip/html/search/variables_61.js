var searchData=
[
  ['age',['age',['../classFredkinCell.html#a755dea54626a9742e4dad6a03755706b',1,'FredkinCell']]],
  ['alive',['alive',['../classAbstractCell.html#aa92e42d5bb67f3249d8e2dde2c3228e7',1,'AbstractCell']]]
];
