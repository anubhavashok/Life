var searchData=
[
  ['reference',['reference',['../classHandle.html#a37f4011e5a2de2482f6b494fa65a82d0',1,'Handle']]],
  ['revive',['revive',['../classAbstractCell.html#ad54cbc59e109d33b811b6fc1a5b446db',1,'AbstractCell::revive()'],['../classCell.html#a908130b21a8c6f6b2397d59b83fd5d9b',1,'Cell::revive()'],['../classConwayCell.html#a6f0b9dde38392a1dafe28a4b235a58e7',1,'ConwayCell::revive()'],['../classFredkinCell.html#ad187791573aaf638d95966bd054cd073',1,'FredkinCell::revive()']]],
  ['runlife_2ec_2b_2b',['RunLife.c++',['../RunLife_8c_09_09.html',1,'']]]
];
