var searchData=
[
  ['life',['Life',['../classLife.html#aa56fd519c607a72d469f0892c0968728',1,'Life::Life(istream &amp;in)'],['../classLife.html#ad5ad51de992a155e52b7808d046310c7',1,'Life::Life(istream &amp;in)'],['../classLife.html#a3f0264e1e4b6a0d8780a4a38844c25c2',1,'Life::Life(istream &amp;in)']]]
];
