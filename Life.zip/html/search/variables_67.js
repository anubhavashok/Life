var searchData=
[
  ['generation',['generation',['../classLife.html#a121e806be4dec87539325f0d5b5abacd',1,'Life']]]
];
