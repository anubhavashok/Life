var searchData=
[
  ['x',['x',['../classLife.html#a6db7f5967adf2919d400fb5711ece7c0',1,'Life']]]
];
