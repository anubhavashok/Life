var searchData=
[
  ['abstractcell',['AbstractCell',['../classAbstractCell.html',1,'AbstractCell'],['../classAbstractCell.html#a6e09d3dc50ef188d85533d8f68fbc2a5',1,'AbstractCell::AbstractCell(bool)'],['../classAbstractCell.html#a1a32801663a2fc4f8dbc05cc5f272547',1,'AbstractCell::AbstractCell(AbstractCell &amp;)']]],
  ['abstractcell_2ec_2b_2b',['AbstractCell.c++',['../AbstractCell_8c_09_09.html',1,'']]],
  ['abstractcell_2eh',['AbstractCell.h',['../AbstractCell_8h.html',1,'']]],
  ['age',['age',['../classFredkinCell.html#a755dea54626a9742e4dad6a03755706b',1,'FredkinCell']]],
  ['alive',['alive',['../classAbstractCell.html#aa92e42d5bb67f3249d8e2dde2c3228e7',1,'AbstractCell']]],
  ['alive_5fneighbors_5fconway',['alive_neighbors_conway',['../classLife.html#a024af157d0acd46b8056ebdae2d1fde2',1,'Life']]],
  ['alive_5fneighbors_5ffredkin',['alive_neighbors_fredkin',['../classLife.html#afe42fb2f092ed4c1d3803805042ec9d3',1,'Life']]]
];
