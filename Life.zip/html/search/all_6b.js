var searchData=
[
  ['kill',['kill',['../classAbstractCell.html#a568ed522f83e17ea20f40bb8665001d9',1,'AbstractCell::kill()'],['../classCell.html#a956d5e8a4aa356fbb4dcfb0e11903836',1,'Cell::kill()'],['../classConwayCell.html#af6ea9e8c8a1fc06fac74b9826a16e9e8',1,'ConwayCell::kill()'],['../classFredkinCell.html#a5750fe80dfca05ef338f1f81842c12e7',1,'FredkinCell::kill()']]]
];
