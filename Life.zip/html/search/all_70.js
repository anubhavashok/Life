var searchData=
[
  ['pointer',['pointer',['../classHandle.html#ae12984dd0ac986f1395eb5f3d6be88e5',1,'Handle']]],
  ['population',['population',['../classLife.html#ad0c82e4ef83bc0b56faf58f28e63e1e2',1,'Life']]]
];
