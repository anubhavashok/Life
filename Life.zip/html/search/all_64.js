var searchData=
[
  ['display',['display',['../classAbstractCell.html#a434bc28dd3f13fca97ff5323f07b43cd',1,'AbstractCell::display()'],['../classCell.html#ad4f500670029964a81add334afd52ac3',1,'Cell::display()'],['../classConwayCell.html#aea824109b8eb00133702462d9967ad7c',1,'ConwayCell::display()'],['../classFredkinCell.html#a6ccc19b53e6b944b9efb7f19d6f268e8',1,'FredkinCell::display()'],['../classLife.html#a881286d1dffea99d5e199c4f78c222ad',1,'Life::display()']]]
];
