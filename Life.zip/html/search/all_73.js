var searchData=
[
  ['simulate',['simulate',['../classLife.html#a1cd7f923e1f36c932a0f429a87df8135',1,'Life']]],
  ['swap',['swap',['../classHandle.html#a48f95f0130205c87c1141e576eb2992f',1,'Handle']]]
];
