var searchData=
[
  ['reference',['reference',['../classHandle.html#a37f4011e5a2de2482f6b494fa65a82d0',1,'Handle']]]
];
