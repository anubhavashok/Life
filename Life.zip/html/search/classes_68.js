var searchData=
[
  ['handle',['Handle',['../classHandle.html',1,'']]],
  ['handle_3c_20abstractcell_20_3e',['Handle< AbstractCell >',['../classHandle.html',1,'']]]
];
